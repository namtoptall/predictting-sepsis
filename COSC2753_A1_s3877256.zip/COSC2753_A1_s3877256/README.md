# Asignment 1 zip folder
 - reults folder: some plotting images (with names)
 - patients_files_test, patiens_files_train : two given dataset
 - cleaned_train: dataset after EDA
 - 2 files report(word and pdf)
 - Since I have to re-run the model after writting report, the result between the report and the model is slightly differences
   However, the apprach and accuracy score range are quite similar

 # 3877256_as1_MachineLearning.ipynb : you just need to open this file hihi

 